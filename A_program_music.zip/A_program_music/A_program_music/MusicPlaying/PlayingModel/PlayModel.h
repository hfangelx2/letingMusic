//
//  PlayModel.h
//  A_program_music
//
//  Created by 姚天成 on 15/6/22.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlayModel : NSObject


@property(nonatomic,copy)NSString *song_name;
@property(nonatomic,copy)NSString *singer_name;
@property(nonatomic,retain)NSMutableArray *audition_list;
@property(nonatomic,copy)NSString *pic_url;

//
//@property(nonatomic,copy)NSString *sectionTitle;
//@property(nonatomic,copy)NSString *itemsTitle;
//@property(nonatomic,copy)NSString *picUrl;


//@property(nonatomic,copy)
//@property(nonatomic,copy)
//@property(nonatomic,copy)
//@property(nonatomic,copy)




@end
