//
//  PlayModel.m
//  A_program_music
//
//  Created by 姚天成 on 15/6/22.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "PlayModel.h"

@implementation PlayModel

#warning 通过拿到歌手名 请求图片 http://so.ard.iyyin.com/s/artist?q=歌手名&page=1&size=15
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{

}
/*
 {
    "code": 1,
     "rows": 1,
     "pages": 1,
         "data": [
             {
                 "_id": 11852,
                 "song_num": 269,
                 "album_num": 30,
                 "singer_name": "周杰伦",
                 "alias_name": "Jay Chou",
                 "pic_url": "http://3p.pic.ttdtweb.com/3p.ttpod.com/singer/11852/1438972.jpg"
             }
         ]
 }
 
 */


@end
