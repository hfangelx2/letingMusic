//
//  SearchAlbumModel.h
//  A_program_music
//
//  Created by 姚天成 on 15/6/22.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SearchAlbumModel : NSObject
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *singer_name;
@property(nonatomic,copy)NSString *publish_time;
@property(nonatomic,copy)NSString *pic200;
@property(nonatomic,copy)NSString *song_ids;
@property(nonatomic,copy)NSString *_id;
@end
