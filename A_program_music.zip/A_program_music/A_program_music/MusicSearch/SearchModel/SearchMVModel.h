//
//  SearchMVModel.h
//  A_program_music
//
//  Created by 姚天成 on 15/6/30.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SearchMVModel : NSObject

@property(nonatomic,copy)NSString *idd;
@property(nonatomic,copy)NSString *title;
@property(nonatomic,copy)NSString *type;
@property(nonatomic,copy)NSString *artistName;
@property(nonatomic,copy)NSString *albumImg;
@property(nonatomic,copy)NSString *posterPic;

@end
