//
//  SearchAlbumModel.m
//  A_program_music
//
//  Created by 姚天成 on 15/6/22.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "SearchAlbumModel.h"

@implementation SearchAlbumModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{



}


@end
