//
//  SearchSingerModel.h
//  A_program_music
//
//  Created by 姚天成 on 15/6/21.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SearchSingerModel : NSObject


@property(nonatomic,copy)NSString *_id;
@property(nonatomic,copy)NSString *singer_name;
@property(nonatomic,copy)NSString *song_num;
@property(nonatomic,copy)NSString *pic_url;
@property(nonatomic,copy)NSString *album_num;
@end
