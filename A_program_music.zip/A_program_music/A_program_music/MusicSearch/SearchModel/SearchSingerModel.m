//
//  SearchSingerModel.m
//  A_program_music
//
//  Created by 姚天成 on 15/6/21.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "SearchSingerModel.h"

@implementation SearchSingerModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{


}
@end
