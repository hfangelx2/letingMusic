//
//  SearchSingerCell.h
//  A_program_music
//
//  Created by 姚天成 on 15/6/21.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "MusicTableViewCell.h"
#import "SearchSingerModel.h"
@interface SearchSingerCell : MusicTableViewCell

@property(nonatomic,retain)SearchSingerModel *model;

@end
