//
//  MusicSetViewController.h
//  A_program_music
//
//  Created by dlios on 15/6/27.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "MusicViewController.h"
#import "RESideMenu.h"
#import "SetViewController.h"

#import "CollectionVC.h"

@interface MusicSetViewController : MusicViewController<UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@end
