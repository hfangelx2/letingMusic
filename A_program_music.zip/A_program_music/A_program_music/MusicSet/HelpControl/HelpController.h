//
//  HelpController.h
//  A_program_music
//
//  Created by 姚天成 on 15/7/5.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "MusicViewController.h"

@interface HelpController : MusicViewController<UIScrollViewDelegate>


@end
