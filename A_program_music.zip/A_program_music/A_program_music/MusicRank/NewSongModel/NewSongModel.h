//
//  NewSongModel.h
//  A_program_music
//
//  Created by dlios on 15/6/23.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewSongModel : NSObject

@property(nonatomic,retain)NSIndexPath *indexpath;

@property(nonatomic,copy)NSString *title;
@property(nonatomic,copy)NSString *pic;
@property(nonatomic,copy)NSString *msg_id;



@end
