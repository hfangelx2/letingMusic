//
//  RankController.h
//  A_program_music
//
//  Created by 姚天成 on 15/6/19.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "MusicViewController.h"
#import "RankViewController.h"
#import "NewSongViewController.h"
#import "SingerTopViewController.h"

@interface RankController : MusicViewController

@end
