//
//  SingerDetailViewCell.h
//  A_program_music
//
//  Created by dlios on 15/6/23.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "MusicTableViewCell.h"
#import "SingerDetailModel.h"

@interface SingerDetailViewCell : MusicTableViewCell


@property(nonatomic,retain)SingerDetailModel *detailModel;


@end
