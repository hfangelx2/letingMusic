//
//  SingerDetailModel.h
//  A_program_music
//
//  Created by dlios on 15/6/23.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SingerDetailModel : NSObject


@property(nonatomic,copy)NSString *singer_name;
@property(nonatomic,copy)NSString *pic_url;
@property(nonatomic,copy)NSString *number;





@end
