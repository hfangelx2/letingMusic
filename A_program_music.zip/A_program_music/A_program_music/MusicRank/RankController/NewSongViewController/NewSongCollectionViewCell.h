//
//  NewSongCollectionViewCell.h
//  A_program_music
//
//  Created by dlios on 15/6/24.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "MusicCollectionViewCell.h"
#import "NewSongModel.h"
@interface NewSongCollectionViewCell : MusicCollectionViewCell


@property(nonatomic,retain)NewSongModel *model;

@end
