




//
//  DetailNewSongModel.m
//  A_program_music
//
//  Created by dlios on 15/6/25.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "DetailNewSongModel.h"

@implementation DetailNewSongModel

@end
