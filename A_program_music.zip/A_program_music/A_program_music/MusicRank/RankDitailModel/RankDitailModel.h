//
//  RankDitailModel.h
//  A_program_music
//
//  Created by dlios on 15/6/22.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RankDitailModel : NSObject

@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *singerName;
@property(nonatomic,copy)NSString *number;
@property(nonatomic,copy)NSString *pic_url;
@property(nonatomic,copy)NSMutableArray *auditionList;








@end
