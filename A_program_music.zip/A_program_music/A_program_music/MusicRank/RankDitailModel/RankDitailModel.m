//
//  RankDitailModel.m
//  A_program_music
//
//  Created by dlios on 15/6/22.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "RankDitailModel.h"

@implementation RankDitailModel

@end
