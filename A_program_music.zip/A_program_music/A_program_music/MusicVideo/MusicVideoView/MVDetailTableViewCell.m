

#import "MVDetailTableViewCell.h"

@implementation MVDetailTableViewCell




- (void)awakeFromNib {
  
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

@end
