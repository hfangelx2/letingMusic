//
//  StorgeModel.h
//  A_program_music
//
//  Created by 姚天成 on 15/6/19.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StorgeModel : NSObject

@property(nonatomic,copy)NSString *parentname;
@property(nonatomic,copy)NSString *songlist_name;
@property(nonatomic,copy)NSString *small_pic_url;
@property(nonatomic,copy)NSString *songlist_Id;
@property(nonatomic,assign)NSInteger number;


@end
