//
//  StorgePlayModel.m
//  A_program_music
//
//  Created by dlios on 15/6/29.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "StorgePlayModel.h"

@implementation StorgePlayModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{


}

@end
