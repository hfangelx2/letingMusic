//
//  DiscoverNewSongController.h
//  A_program_music
//
//  Created by 姚天成 on 15/6/24.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "MusicViewController.h"
#import "ChineseController.h"
#import "AmericaController.h"
#import "KoreaController.h"


@interface DiscoverNewSongController : MusicViewController

@property(nonatomic,retain)NSMutableArray *idArray;

@end
