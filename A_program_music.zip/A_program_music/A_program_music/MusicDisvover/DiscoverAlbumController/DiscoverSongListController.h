//
//  DiscoverSongListController.h
//  A_program_music
//
//  Created by 姚天成 on 15/6/24.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "MusicViewController.h"

@interface DiscoverSongListController : MusicViewController

@property(nonatomic,copy)NSString *albumId;
@property(nonatomic,copy)NSString *titleName;


@end
