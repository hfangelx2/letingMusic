//
//  DiscoverCell.h
//  A_program_music
//
//  Created by 姚天成 on 15/6/19.
//  Copyright (c) 2015年 CHD. All rights reserved.
//

#import "MusicTableViewCell.h"
#import "DownLoadImage.h"
#import "DiscoverModel.h"


@interface DiscoverCell : MusicTableViewCell

@property(nonatomic,retain)DiscoverModel *model;

@end
